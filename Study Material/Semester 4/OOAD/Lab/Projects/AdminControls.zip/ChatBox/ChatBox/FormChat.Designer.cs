﻿namespace ChatBox
{
    partial class FormChat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowChatHead = new System.Windows.Forms.FlowLayoutPanel();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtChat = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // flowChatHead
            // 
            this.flowChatHead.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.flowChatHead.AutoScroll = true;
            this.flowChatHead.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.flowChatHead.Location = new System.Drawing.Point(12, 12);
            this.flowChatHead.Name = "flowChatHead";
            this.flowChatHead.Size = new System.Drawing.Size(316, 157);
            this.flowChatHead.TabIndex = 0;
            this.flowChatHead.Paint += new System.Windows.Forms.PaintEventHandler(this.flowChatHead_Paint);
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(12, 175);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 1;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtChat
            // 
            this.txtChat.Location = new System.Drawing.Point(109, 178);
            this.txtChat.Name = "txtChat";
            this.txtChat.Size = new System.Drawing.Size(219, 20);
            this.txtChat.TabIndex = 2;
            // 
            // FormChat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 307);
            this.Controls.Add(this.txtChat);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.flowChatHead);
            this.Name = "FormChat";
            this.Text = "FormChat";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowChatHead;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtChat;
    }
}

