﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserControlOoad
{
    class Users
    {
        public static List<User> RegisteredUsers = new List<User>();
        public static List<User> ApprovedUsers = new List<User>();

        public static bool ExistInRegisteredUsers(User user) // Check if a user exits in the List
        {
            foreach(User u in Users.RegisteredUsers)
            {
                if(user.Username == u.Username)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool ExistInApprovedUsers(User user) // Check if a user exits in the List
        {
            foreach (User u in Users.ApprovedUsers)
            {
                if (user.Username == u.Username)
                {
                    return true;
                }
            }
            return false;
        }

        
        public static void UpdateUserLists()
        {   // Update both lists
            // none of the users should exist in both lists
            List<User> temp = new List<User>();
            foreach(User u in Users.RegisteredUsers)
            {
                if(u.IsApproved)
                {
                    Users.ApprovedUsers.Add(u);
                    temp.Add(u);
                }
            }
            // There should be removal of a registered user that is added in ApprovedUsers
            foreach(User u in Users.ApprovedUsers)
            {
                Users.RegisteredUsers.Remove(u);
            }
            
        }
    }
}
