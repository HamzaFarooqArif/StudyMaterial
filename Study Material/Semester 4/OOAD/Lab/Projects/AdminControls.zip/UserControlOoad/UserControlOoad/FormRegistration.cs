﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserControlOoad
{
    public partial class FormRegistration : Form
    {
        public static FormRegistration formRegistration = null;
        public FormRegistration()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if(chkIsAdmin.Checked)
            {
                if(AdminDL.AdminList.Count == 0)
                {
                    Admin a = new Admin();
                    a.Username = txtUsername.Text;
                    a.Password = txtPassword.Text;
                    AdminDL.AdminList.Add(a);

                    lblInfo.Text = "Registered As Admin";
                }
                else
                {
                    lblInfo.Text = "Admin Already Exists";
                }
            }
            else
            {
                User u = new User(); // Instantiate a new User
                u.Username = txtUsername.Text; // Set Username of user as text in UserName textbox
                u.Password = txtPassword.Text; // Set Password of user as text in Password textbox
                u.IsApproved = false; // Newly registered user should wait for approval

                // See if being registered Username already exists
                if (!(Users.ExistInRegisteredUsers(u) || Users.ExistInApprovedUsers(u)))
                {
                    Users.RegisteredUsers.Add(u);
                    lblInfo.Text = "User Registered";
                }
                else
                {
                    lblInfo.Text = "User Already Exists"; // Display Error
                }
            }
            
        }

        private void lnkLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            formRegistration = this;
            if (FormLogin.formLogin == null)
            {
                FormLogin.formLogin = new FormLogin();
            }

            this.Hide();
            FormLogin.formLogin.Show();
        }
    }
}
