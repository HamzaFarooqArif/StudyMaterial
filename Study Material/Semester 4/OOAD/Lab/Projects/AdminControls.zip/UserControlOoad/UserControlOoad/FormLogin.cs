﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserControlOoad
{
    
    public partial class FormLogin : Form
    {
        public static FormLogin formLogin = null;
        public FormLogin()
        {
            InitializeComponent();
        }


        private void btnLogin_Click(object sender, EventArgs e)
        {

            if (chkIsAdmin.Checked)
            {
                if (AdminDL.AdminList.Count == 0)
                {
                    lblInfo.Text = "Admin Doesnt exist";
                }
                else
                {
                    foreach (Admin a in AdminDL.AdminList)
                    {
                        if (a.Username == txtUsername.Text && a.Password == txtPassword.Text)
                        {
                            lblInfo.Text = "Login Successful";
                            formLogin = this;
                            if (FormMain.formMain == null)
                            {
                                FormMain.formMain = new FormMain();
                            }

                            this.Hide();
                            FormMain.formMain.Show();
                        }
                        else
                        {
                            lblInfo.Text = "Invalid Credentials";
                        }
                    }
                }
            }
            else
            {
                foreach (User u in Users.RegisteredUsers)
                {
                    if (u.Username == txtUsername.Text && u.Password == txtPassword.Text)
                    {
                        lblInfo.Text = "Approval Pending";
                        return;
                    }
                }

                foreach (User u in Users.ApprovedUsers)
                {
                    if (u.Username == txtUsername.Text && u.Password == txtPassword.Text)
                    {
                        lblInfo.Text = "Approved User";
                        return;
                    }
                }

                lblInfo.Text = "Invalid Credentials";
            }
            
        }

        private void lnkRegistrationForm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            formLogin = this;
            if (FormRegistration.formRegistration == null)
            {
                FormRegistration.formRegistration = new FormRegistration();
            }

            this.Hide();
            FormRegistration.formRegistration.Show();
        }
    }
}
