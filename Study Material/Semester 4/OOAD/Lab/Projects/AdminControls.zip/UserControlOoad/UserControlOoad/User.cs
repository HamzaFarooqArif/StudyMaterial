﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserControlOoad
{
    class User
    {
        private string username;
        private string password;
        private bool isApproved;

        public string Username
        {
            get
            {
                return username;
            }

            set
            {
                username = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public bool IsApproved
        {
            get
            {
                return isApproved;
            }

            set
            {
                isApproved = value;
            }
        }
    }
}
