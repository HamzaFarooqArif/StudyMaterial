﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserControlOoad
{
    public partial class FormMain : Form
    {
        public static FormMain formMain = null;
        public FormMain()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            User u = new User(); // Instantiate a new User
            u.Username = txtUserName.Text; // Set Username of user as text in UserName textbox
            u.Password = txtPassword.Text; // Set Password of user as text in Password textbox
            u.IsApproved = false; // Newly registered user should wait for approval

            // See if being registered Username already exists
            if (!(Users.ExistInRegisteredUsers(u) || Users.ExistInApprovedUsers(u))) 
            {
                Users.RegisteredUsers.Add(u);
                lblInfo.Text = "User Registered";
            }
            else
            {
                lblInfo.Text = "User Already Exists"; // Display Error
            }
        }

        public void RefreshFlowRegistered() // Refresh flow layout for registered users
        {
            flowRegistered.Controls.Clear(); // Clear flow layout before updating
            foreach(User u in Users.RegisteredUsers)
            {
                // Instantiate a new user control for each registered user
                UserControl1 uc = new UserControl1(u.Username, u.Password, u.IsApproved);
                flowRegistered.Controls.Add(uc);
            }
        }

        public void RefreshFlowApproved() // Refresh flow layout for Approved users
        {
            flowApproved.Controls.Clear();
            foreach (User u in Users.ApprovedUsers)
            {
                // Instantiate a new user control for each Approved user
                UserControl1 uc = new UserControl1(u.Username, u.Password, u.IsApproved);
                flowApproved.Controls.Add(uc);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Users.UpdateUserLists(); // Update RegisterdUsers and ApprovedUsers Lists 
            RefreshFlowRegistered(); // Update RefreshFlowRegistered Flow Layot
            RefreshFlowApproved();  // Update RefreshFlowRegistered Flow Layot

        }

        private void lnkLoginForm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            formMain = this;
            if (FormLogin.formLogin == null)
            {
                FormLogin.formLogin = new FormLogin();
            }

            this.Hide();
            FormLogin.formLogin.Show();
        }

        private void lnkRegistrationForm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            formMain = this;
            if (FormRegistration.formRegistration == null)
            {
                FormRegistration.formRegistration = new FormRegistration();
            }

            this.Hide();
            FormRegistration.formRegistration.Show();
        }
    }
}
