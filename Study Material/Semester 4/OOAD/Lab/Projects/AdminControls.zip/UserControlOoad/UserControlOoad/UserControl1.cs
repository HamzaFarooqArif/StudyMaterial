﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserControlOoad
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        public UserControl1(string Username, string Password, bool isApproved) // Parameterized Null Constructor
        {
            InitializeComponent();
            lblUserName.Text = Username;
            lblPassword.Text = Password;
            checkIsApproved.Checked = isApproved;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        // Called whenever checkbox is checked or unchecked
        private void checkIsApproved_CheckedChanged(object sender, EventArgs e)
        {
            // Perform Approval of a user 
            foreach(User u in Users.RegisteredUsers)
            {
                if(lblUserName.Text == u.Username)
                {
                    // User is still in Registerd Users 
                    u.IsApproved = true;
                    
                }
            }
        }
    }
}
