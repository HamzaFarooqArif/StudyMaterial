﻿namespace UserControlOoad
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowRegistered = new System.Windows.Forms.FlowLayoutPanel();
            this.flowApproved = new System.Windows.Forms.FlowLayoutPanel();
            this.btnRegister = new System.Windows.Forms.Button();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblInfo = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lnkLoginForm = new System.Windows.Forms.LinkLabel();
            this.lnkRegistrationForm = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // flowRegistered
            // 
            this.flowRegistered.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.flowRegistered.Location = new System.Drawing.Point(0, 0);
            this.flowRegistered.Name = "flowRegistered";
            this.flowRegistered.Size = new System.Drawing.Size(440, 216);
            this.flowRegistered.TabIndex = 0;
            // 
            // flowApproved
            // 
            this.flowApproved.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.flowApproved.Location = new System.Drawing.Point(449, 0);
            this.flowApproved.Name = "flowApproved";
            this.flowApproved.Size = new System.Drawing.Size(440, 216);
            this.flowApproved.TabIndex = 1;
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(46, 235);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(75, 23);
            this.btnRegister.TabIndex = 2;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(154, 240);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(100, 20);
            this.txtUserName.TabIndex = 3;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(154, 266);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(100, 20);
            this.txtPassword.TabIndex = 4;
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(151, 224);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(87, 13);
            this.lblInfo.TabIndex = 0;
            this.lblInfo.Text = "Enter Credentials";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(405, 222);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 23);
            this.btnRefresh.TabIndex = 5;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // lnkLoginForm
            // 
            this.lnkLoginForm.AutoSize = true;
            this.lnkLoginForm.Location = new System.Drawing.Point(43, 273);
            this.lnkLoginForm.Name = "lnkLoginForm";
            this.lnkLoginForm.Size = new System.Drawing.Size(59, 13);
            this.lnkLoginForm.TabIndex = 6;
            this.lnkLoginForm.TabStop = true;
            this.lnkLoginForm.Text = "Login Form";
            this.lnkLoginForm.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkLoginForm_LinkClicked);
            // 
            // lnkRegistrationForm
            // 
            this.lnkRegistrationForm.AutoSize = true;
            this.lnkRegistrationForm.Location = new System.Drawing.Point(272, 271);
            this.lnkRegistrationForm.Name = "lnkRegistrationForm";
            this.lnkRegistrationForm.Size = new System.Drawing.Size(89, 13);
            this.lnkRegistrationForm.TabIndex = 7;
            this.lnkRegistrationForm.TabStop = true;
            this.lnkRegistrationForm.Text = "Registration Form";
            this.lnkRegistrationForm.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRegistrationForm_LinkClicked);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(901, 293);
            this.Controls.Add(this.lnkRegistrationForm);
            this.Controls.Add(this.lnkLoginForm);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUserName);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.flowApproved);
            this.Controls.Add(this.flowRegistered);
            this.Name = "FormMain";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowRegistered;
        private System.Windows.Forms.FlowLayoutPanel flowApproved;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.LinkLabel lnkLoginForm;
        private System.Windows.Forms.LinkLabel lnkRegistrationForm;
    }
}

