% Question 4
%
%    ------------------------------------------------------------
%       NUMARICAL ANALYSIS IN COMPUTER SCIENCE AND ENGINEERING
%    ------------------------------------------------------------
% Numerical Analysis is keenly concerned with the
% computational procedures and analytic efficient programs. We develop the
% programs to calculate the solution or approximation of a complex
% mathematical problem.
% Numerical Analysis don't have a big role in computer science but it may
% have a big role in Grading. As all the students are writing the paragraph
% to get the higher marks. 
% We will cover the basic as well as advanced thing in computational
% consequences and we will observe that how much and upto what extent the
% negligible values and erros can effect the final result and how can we
% set the tolerance to make the final result precise as well as accurate.
% 1. Numerical Analysis may have been important but may be in mathematics
%    and statistics. It plays an important role in Stad as well.
% 2. Mam. Sahar said that it is not so important course.
% 3. We are already messed up with COAL, DSA and OOAD labs.
% 4. Using Numerical Analysis, we can Simulate a virtual world.
% 5. After learning this course, we can predict the results and can build 
%    complex structues more precise. 