function S = mysum(n)
         S = 0;
         for i = 1:n
             S = S + i;
         end
end