function y = Q3(x)
         y = pi.*((x.^2)/4);
end