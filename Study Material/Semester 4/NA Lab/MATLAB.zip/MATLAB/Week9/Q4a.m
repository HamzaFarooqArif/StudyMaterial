% Q4 Part A-------------------------------------------------------
format long;
format compact;
A = [1.2969 .8648; .2161 .1441]; % Given Matrix A
disp('Determinant of A is:');
det(A) % Display Determinant of matrix A
disp('Inverse of A is:');
inv(A) % Display Inverse of matrix A
