 f = @(x) sqrt(x); % Declare an anonymous function
 mymidpoint(f,1,2,4) % mymidpoint function call for n = 4
 mymidpoint(f,1,2,100) % mymidpoint function call for n = 100