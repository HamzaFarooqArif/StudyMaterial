function = func(x)
z= x
end
