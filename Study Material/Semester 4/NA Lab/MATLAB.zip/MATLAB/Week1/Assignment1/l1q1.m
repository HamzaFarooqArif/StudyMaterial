% Question1
% plots the graphs of Pressure versus Volume
% graph is a isothermal graph that is verification of Boyle's law

% Pressure vector on X-axis:
x = [21.4 24.8 29.5 34.9 41.7 50.3 171];
% Volume vector on Y-axis:
y = [8 6.9 5.8 4.9 4.1 3.4 1];

% Plot the Isothermal graph
plot(y, x)