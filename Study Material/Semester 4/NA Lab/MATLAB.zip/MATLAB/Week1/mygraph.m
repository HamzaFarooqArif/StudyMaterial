x2 = x.^2;
x3 = x.^3;
x4 = x.^4;
plot(x, x, 'black', x, x2, 'blue', x, x3, 'green', x, x4, 'red')
