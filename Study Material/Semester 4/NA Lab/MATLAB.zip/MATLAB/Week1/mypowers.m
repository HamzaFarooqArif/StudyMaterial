function [x2 x3 x4] = mypowers (x)
x2 = x.^2;
x3 = x.^3;
x4 = x.^4;
end