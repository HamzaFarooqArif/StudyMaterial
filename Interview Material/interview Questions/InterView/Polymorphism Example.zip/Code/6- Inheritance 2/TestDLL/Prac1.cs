﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestDLL
{
    //Public class
    public class Class1
    {
    }

    //By default a type has 'internal' access modifier
    class Class2
    {

    }

    internal class Class3
    {

    }
}
